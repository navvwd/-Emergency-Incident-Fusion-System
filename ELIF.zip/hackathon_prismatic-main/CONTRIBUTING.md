# Contributing — Parallel Work Playbook

Two devs (`muhammedsayeedurrahman` + `rarba-noobdev`) are shipping this
during a hackathon. Parallel work only goes fast if we avoid stepping on
each other's toes. Rules below are non-negotiable.

## 1. Branch per person, not per feature

```
main                       ← protected, merges via PR only
├── feat/sayeed-<scope>    ← muhammedsayeedurrahman works here
└── feat/naveeth-<scope>   ← rarba-noobdev works here
```

**Never both commit directly to `main`.** Always open a PR.

## 2. Split the domain, not the files

Before you start anything new, agree *out loud* on who owns which slice:

| Slice                                | Owner    |
| ------------------------------------ | -------- |
| `server/src/routes/*`                | TBD      |
| `server/src/services/sarvam.ts`      | TBD      |
| `server/src/services/moonshot.ts`    | TBD      |
| `server/src/services/dedup.ts`       | TBD      |
| `client/src/components/dashboard/*`  | TBD      |
| `client/src/components/agent/*`      | TBD      |
| `client/src/lib/*`                   | TBD      |
| `supabase/migrations/*`              | TBD      |

**Update this table in the same commit where you claim a slice.** If you
need to touch another person's slice, ping them in chat first.

## 3. Pull before you push

Every time you return to your branch:

```bash
git fetch origin
git rebase origin/main   # pull in teammate's merged work
# …work…
git push --force-with-lease
```

`--force-with-lease` is safe (refuses to clobber someone else's push);
`--force` is not. Never use plain `--force` on shared branches.

## 4. Small PRs, fast merges

- **Aim for PRs under ~300 changed lines.** A PR that sits open for hours
  becomes a conflict magnet.
- **Merge your own PR as soon as it's green** — don't wait for the other
  person to review non-trivial frontend/backend isolation.
- **Review only what touches your slice.** Trust each other's work on
  their own slice to keep velocity up.

## 5. Never commit these

- `.env` files (already in `.gitignore`)
- Build artifacts (`dist/`, `android/.gradle/`, `*.log`) — already ignored
- API keys, tokens, secrets of any kind (see the security incident
  recovered from in PR #2 — we do not repeat this)
- Package-lock merge conflicts: if `package-lock.json` conflicts, **delete
  it and re-run `npm install`**. Never hand-merge lockfiles.

## 6. Environment

```bash
# First-time setup
cp server/.env.example server/.env  # then fill in rotated keys
cp client/.env.example client/.env  # then fill in Supabase

# Install
cd server && npm install
cd ../client && npm install --legacy-peer-deps

# Run (two terminals)
cd server && npm run dev   # http://localhost:3001
cd client && npm run dev   # http://localhost:5173
```

## 7. When you're about to touch a shared file

1. Check `git log --oneline -5 <path>` — who was here last?
2. If it's the other person, ping them before editing.
3. If it's urgent, open a tiny PR that only changes the signature/imports
   so they can rebase their branch onto it painlessly.

## 8. Commit message format

```
<type>: <short description under 70 chars>

<optional body explaining why — not what>
```

Types: `feat`, `fix`, `refactor`, `chore`, `docs`, `test`, `perf`, `security`.

## 9. If in doubt — ask

Hackathons reward speed, but a five-minute chat about "who's touching X"
always beats a fifty-minute merge fight.
