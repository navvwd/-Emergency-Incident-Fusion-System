-- ═══════════════════════════════════════════════════════════════════
-- EIFS — Multi-Metric Fusion Algorithm (Migration 002)
-- ═══════════════════════════════════════════════════════════════════
-- Adds everything the server/src/services/{fusion,dedup}.ts files
-- expect beyond the initial schema:
--
--   • find_fusion_candidates_v1  — wide-net candidate retrieval RPC
--   • merge_into_incident_v2     — 6-param merge with lat/lng + summary
--   • fusion_log                 — audit trail for every dedup decision
--   • raw_reports.dedup_status   — soft status tag for each raw report
--
-- Apply via Supabase Dashboard → SQL Editor → New Query → paste → Run.
-- All statements are idempotent so re-running is safe.
-- ═══════════════════════════════════════════════════════════════════

-- ─── 1. dedup_status column on raw_reports ─────────────────────────
ALTER TABLE raw_reports
  ADD COLUMN IF NOT EXISTS dedup_status TEXT
    CHECK (dedup_status IN (
      'completed',
      'skipped_no_embedding',
      'skipped_error',
      'skipped_timeout'
    ));

-- ─── 2. fusion_log table ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fusion_log (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id           UUID NOT NULL REFERENCES raw_reports(id) ON DELETE CASCADE,
  matched_incident_id UUID REFERENCES incidents(id) ON DELETE SET NULL,
  fusion_score        FLOAT NOT NULL,
  score_breakdown     JSONB NOT NULL,
  decision            TEXT NOT NULL CHECK (decision IN ('merged', 'new_incident')),
  input_text          TEXT,
  embedding_hash      TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_fusion_log_report ON fusion_log (report_id);
CREATE INDEX IF NOT EXISTS idx_fusion_log_incident ON fusion_log (matched_incident_id);
CREATE INDEX IF NOT EXISTS idx_fusion_log_created ON fusion_log (created_at DESC);

-- ─── 3. find_fusion_candidates_v1 RPC ──────────────────────────────
-- Wide-net candidate retrieval:
--   • semantic_threshold: pgvector cosine-similarity cutoff (default 0.60)
--   • time_window_hours:  only look at incidents updated in the last N hours
--   • max_candidates:     hard cap on returned rows
--
-- Returns one row per candidate incident with the max semantic_similarity
-- across all of that incident's raw_reports, plus enough fields for the
-- multi-metric fusion scorer (fusion.ts:computeFusionScore).
CREATE OR REPLACE FUNCTION find_fusion_candidates_v1(
  query_embedding      VECTOR(1536),
  semantic_threshold   FLOAT DEFAULT 0.60,
  time_window_hours    INT DEFAULT 4,
  max_candidates       INT DEFAULT 5
)
RETURNS TABLE (
  incident_id          UUID,
  semantic_similarity  FLOAT,
  location             TEXT,
  latitude             FLOAT,
  longitude            FLOAT,
  incident_type        TEXT,
  affected_count       INT,
  severity_score       INT,
  summary              TEXT,
  report_count         INT,
  created_at           TIMESTAMPTZ,
  updated_at           TIMESTAMPTZ
)
LANGUAGE sql STABLE AS $$
  WITH scored AS (
    SELECT
      r.incident_id,
      MAX(1 - (r.embedding <=> query_embedding)) AS semantic_similarity
    FROM raw_reports r
    WHERE r.incident_id IS NOT NULL
      AND r.embedding IS NOT NULL
      AND (1 - (r.embedding <=> query_embedding)) > semantic_threshold
    GROUP BY r.incident_id
  )
  SELECT
    i.id                AS incident_id,
    s.semantic_similarity,
    i.location,
    i.latitude,
    i.longitude,
    i.incident_type,
    i.affected_count,
    i.severity_score,
    i.summary,
    i.report_count,
    i.created_at,
    i.updated_at
  FROM scored s
  JOIN incidents i ON i.id = s.incident_id
  WHERE i.status = 'active'
    AND i.updated_at > now() - (time_window_hours || ' hours')::INTERVAL
  ORDER BY s.semantic_similarity DESC
  LIMIT max_candidates;
$$;

-- ─── 4. merge_into_incident_v2 RPC ─────────────────────────────────
-- 6-parameter merge that also updates lat/lng (if newly available)
-- and appends to the summary while bumping report_count + severity.
CREATE OR REPLACE FUNCTION merge_into_incident_v2(
  p_incident_id         UUID,
  p_new_affected_count  INT,
  p_new_severity        INT,
  p_new_latitude        FLOAT,
  p_new_longitude       FLOAT,
  p_new_summary         TEXT
)
RETURNS void
LANGUAGE plpgsql AS $$
BEGIN
  UPDATE incidents SET
    report_count   = report_count + 1,
    affected_count = GREATEST(affected_count, p_new_affected_count),
    severity_score = GREATEST(severity_score, p_new_severity),
    -- Only overwrite lat/lng when the incident has none yet
    latitude       = COALESCE(latitude, p_new_latitude),
    longitude      = COALESCE(longitude, p_new_longitude),
    -- Keep the longer summary so detail isn't lost on merge
    summary        = CASE
                       WHEN p_new_summary IS NOT NULL
                         AND length(p_new_summary) > length(COALESCE(summary, ''))
                       THEN p_new_summary
                       ELSE summary
                     END,
    updated_at     = now()
  WHERE id = p_incident_id;
END;
$$;

-- ─── 5. Realtime + grants ──────────────────────────────────────────
-- Make sure fusion_log is visible to the same anon-key subscribers
-- the client uses for incident realtime updates.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'fusion_log'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE fusion_log;
  END IF;
END$$;
