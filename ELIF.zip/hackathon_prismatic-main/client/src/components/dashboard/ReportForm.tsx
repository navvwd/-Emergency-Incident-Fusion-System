// ═══════════════════════════════════════════════════════════
// EIFS — Report Submission Form
// Unified ChatGPT-style composer: text + voice + image
// in a single input section.
// ═══════════════════════════════════════════════════════════

import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Mic, Send, Loader2, Square,
  X, CheckCircle, AlertCircle, Paperclip, Image as ImageIcon, Siren
} from 'lucide-react';
import { toast } from 'sonner';
import api from '../../lib/api';

interface ReportFormProps {
  onSuccess?: () => void;
}

type Attachment =
  | { kind: 'image'; file: File; previewUrl: string }
  | { kind: 'voice'; file: File; previewUrl: string; duration: number };

export default function ReportForm({ onSuccess }: ReportFormProps) {
  const [textVal, setTextVal] = useState('');
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  // Audio recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Auto-grow textarea up to ~160px
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = '0px';
    ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
  }, [textVal]);

  // Revoke attachment preview URLs when replaced/unmounted
  useEffect(() => {
    if (!attachment) return;
    return () => URL.revokeObjectURL(attachment.previewUrl);
  }, [attachment]);

  // ═══════════════════════════════════════════════════════════
  // Attachment helpers
  // ═══════════════════════════════════════════════════════════

  const clearAttachment = () => setAttachment(null);

  const setImageAttachment = (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast.error('Please choose an image file (JPEG, PNG).');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image must be under 5MB.');
      return;
    }
    setAttachment({ kind: 'image', file, previewUrl: URL.createObjectURL(file) });
  };

  // ═══════════════════════════════════════════════════════════
  // Recording
  // ═══════════════════════════════════════════════════════════

  const startRecording = async () => {
    if (isRecording || isSubmitting) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      // Replace any existing attachment when starting a new recording
      clearAttachment();
      setIsRecording(true);
      setRecordingDuration(0);

      recorder.start();
      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration((d) => d + 1);
      }, 1000);
    } catch {
      toast.error('Microphone access denied. Please allow microphone access to record.');
    }
  };

  const stopRecording = () => {
    const recorder = mediaRecorderRef.current;
    if (!recorder || !isRecording) return;

    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }

    // Capture the final duration in closure so onstop can use it
    const finalDuration = recordingDuration;
    recorder.onstop = () => {
      const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
      const file = new File([blob], `voice-report-${Date.now()}.webm`, { type: 'audio/webm' });
      const url = URL.createObjectURL(blob);
      setAttachment({ kind: 'voice', file, previewUrl: url, duration: finalDuration });
    };

    recorder.stop();
    recorder.stream.getTracks().forEach((t) => t.stop());
    setIsRecording(false);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // ═══════════════════════════════════════════════════════════
  // Drag & Drop (image only)
  // ═══════════════════════════════════════════════════════════

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else if (e.type === 'dragleave') setDragActive(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) setImageAttachment(dropped);
  }, []);

  // ═══════════════════════════════════════════════════════════
  // Submit
  // ═══════════════════════════════════════════════════════════

  const hasText = textVal.trim().length > 0;
  const hasAttachment = attachment !== null;
  const canSubmit = !isSubmitting && !isRecording && (hasText || hasAttachment);

  const handleSubmit = async () => {
    if (!canSubmit) {
      if (!hasText && !hasAttachment) {
        toast.error('Describe the incident or attach voice/image.');
      }
      return;
    }

    setIsSubmitting(true);
    const formData = new FormData();

    // Backend is strict one-of: attachment wins over text.
    // When both are present we send the attachment; the UI has already
    // warned the user that text is optional context only.
    if (attachment?.kind === 'image') {
      formData.append('report_type', 'image');
      formData.append('file', attachment.file);
    } else if (attachment?.kind === 'voice') {
      formData.append('report_type', 'voice');
      formData.append('file', attachment.file);
    } else {
      formData.append('report_type', 'text');
      formData.append('text_content', textVal);
    }

    // ── GPS capture: two-phase strategy ─────────────────────
    // Phase 1: fast/cached low-accuracy fix (1.5 s)
    // Phase 2: full high-accuracy fix (15 s)  (cold-fix fallback)
    const getPositionWith = (opts: PositionOptions): Promise<GeolocationPosition> =>
      new Promise((resolve, reject) => {
        if (!('geolocation' in navigator)) {
          reject(new Error('Geolocation API not available in this browser'));
          return;
        }
        navigator.geolocation.getCurrentPosition(resolve, reject, opts);
      });

    try {
      let pos: GeolocationPosition;
      try {
        pos = await getPositionWith({
          enableHighAccuracy: false,
          timeout: 1500,
          maximumAge: 5 * 60_000, // accept up to a 5-minute-old cached fix
        });
      } catch {
        pos = await getPositionWith({
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 0,
        });
      }
      formData.append('latitude', pos.coords.latitude.toString());
      formData.append('longitude', pos.coords.longitude.toString());
      console.log(
        `[GPS] Captured ${pos.coords.latitude.toFixed(5)},${pos.coords.longitude.toFixed(5)} ` +
          `(±${Math.round(pos.coords.accuracy)} m)`,
      );
    } catch (err) {
      const gpsErr = err as GeolocationPositionError | Error;
      const code = (gpsErr as GeolocationPositionError).code;
      console.warn('[GPS] Location capture failed:', code, gpsErr.message);

      if (code === 1) {
        toast.warning('Location permission denied — incident may show unspecified location.');
      } else if (code === 3) {
        toast.warning('Location timed out — incident may show unspecified location.');
      } else {
        toast.warning('Location unavailable — incident may show unspecified location.');
      }
    }

    try {
      const response = await api.post('/api/ingest-report', formData);

      setTextVal('');
      clearAttachment();

      toast.success(
        response.data.is_merged
          ? 'Report merged with existing incident'
          : 'New incident created successfully',
        { icon: <CheckCircle size={16} /> }
      );
      onSuccess?.();
    } catch (err: any) {
      console.error(err);
      toast.error(err.response?.data?.error || 'Failed to submit report', {
        icon: <AlertCircle size={16} />,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Enter to submit, Shift+Enter for newline
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  // ═══════════════════════════════════════════════════════════
  // Render
  // ═══════════════════════════════════════════════════════════

  const isEmpty = !hasText && !hasAttachment && !isRecording;

  return (
    <div
      className="relative w-full h-full flex flex-col"
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
    >
      {/* Drag-drop overlay */}
      {dragActive && (
        <div className="absolute inset-0 z-30 bg-[var(--accent-green)]/10 border-2 border-dashed border-[var(--accent-green)] rounded-2xl flex items-center justify-center pointer-events-none">
          <div className="bg-[var(--bg-elevated)] px-6 py-4 rounded-xl shadow-xl text-[var(--accent-green)] font-semibold flex items-center gap-2">
            <ImageIcon size={20} />
            Drop image to attach
          </div>
        </div>
      )}

      {/* Empty state hint (fills space above the composer) */}
      {isEmpty && (
        <div className="flex-1 flex flex-col items-center justify-center text-center px-4 py-6">
          <div className="w-16 h-16 rounded-2xl bg-[var(--bg-tertiary)] flex items-center justify-center mb-4 text-[var(--text-secondary)]">
            <Siren size={28} strokeWidth={1.5} />
          </div>
          <h3 className="text-[var(--text-primary)] font-semibold text-base mb-1">
            Report an Emergency
          </h3>
          <p className="text-sm text-[var(--text-tertiary)] max-w-xs leading-relaxed">
            Describe what you see, record your voice, or attach a photo. Everything goes into a single report.
          </p>
        </div>
      )}

      {/* Spacer to push composer to bottom when there's an attachment/recording but no hint */}
      {!isEmpty && <div className="flex-1" />}

      {/* Composer card */}
      <div
        className={`
          relative w-full bg-[var(--bg-primary)] border rounded-2xl transition-all duration-200 shadow-sm
          ${isRecording
            ? 'border-[var(--accent-red)]/60 shadow-red-500/10'
            : 'border-[var(--border-subtle)] focus-within:border-[var(--border-default)] focus-within:shadow-md'
          }
        `}
      >
        {/* Attachment preview */}
        {attachment && !isRecording && (
          <div className="px-3 pt-3">
            {attachment.kind === 'image' ? (
              <div className="relative inline-block">
                <img
                  src={attachment.previewUrl}
                  alt="Attached"
                  className="h-24 rounded-xl object-cover border border-[var(--border-subtle)]"
                />
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={clearAttachment}
                  aria-label="Remove image"
                  className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-[var(--bg-elevated)] border border-[var(--border-subtle)] text-[var(--text-primary)] hover:bg-[var(--accent-red)] hover:text-white hover:border-[var(--accent-red)] transition-colors flex items-center justify-center shadow-md"
                >
                  <X size={12} />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-3 bg-[var(--bg-tertiary)] rounded-xl p-2.5 border border-[var(--border-subtle)]">
                <div className="w-9 h-9 rounded-full bg-[var(--accent-red)]/15 text-[var(--accent-red)] flex items-center justify-center shrink-0">
                  <Mic size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold text-[var(--text-primary)]">Voice note</div>
                  <div className="text-[10px] text-[var(--text-tertiary)]">{formatDuration(attachment.duration)}</div>
                </div>
                <audio src={attachment.previewUrl} controls className="h-8 max-w-[160px]" />
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={clearAttachment}
                  aria-label="Remove audio"
                  className="w-7 h-7 rounded-full text-[var(--text-tertiary)] hover:bg-[var(--accent-red)]/15 hover:text-[var(--accent-red)] transition-colors flex items-center justify-center shrink-0"
                >
                  <X size={14} />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Recording indicator */}
        {isRecording && (
          <div className="flex items-center gap-3 px-4 pt-4">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-[var(--accent-red)] animate-pulse" />
              <span className="text-sm text-[var(--text-secondary)]">Recording…</span>
            </div>
            <span className="ml-auto font-mono text-sm font-semibold text-[var(--accent-red)] tracking-wider">
              {formatDuration(recordingDuration)}
            </span>
          </div>
        )}

        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={textVal}
          onChange={(e) => setTextVal(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isSubmitting || isRecording}
          rows={1}
          placeholder={
            isRecording
              ? 'Recording voice note…'
              : attachment
                ? 'Add optional context… (only the attachment will be processed)'
                : 'Describe the emergency or attach voice/image…'
          }
          className="w-full bg-transparent resize-none outline-none text-[var(--text-primary)] placeholder-[var(--text-muted)] text-base leading-relaxed px-4 pt-3 pb-2 min-h-[44px] max-h-[160px] disabled:opacity-70"
        />

        {/* Toolbar */}
        <div className="flex items-center gap-1 px-2 pb-2 pt-1">
          {/* Image attach */}
          <input
            ref={imageInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            disabled={isSubmitting || isRecording}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) setImageAttachment(f);
              e.target.value = '';
            }}
          />
          <button
            type="button"
            disabled={isSubmitting || isRecording}
            onClick={() => imageInputRef.current?.click()}
            aria-label="Attach image"
            title="Attach image"
            className="w-10 h-10 rounded-lg flex items-center justify-center text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)] transition-colors disabled:opacity-40 disabled:hover:bg-transparent focus-ring"
          >
            <Paperclip size={18} />
          </button>

          {/* Voice record toggle */}
          <button
            type="button"
            disabled={isSubmitting}
            onClick={isRecording ? stopRecording : startRecording}
            aria-label={isRecording ? 'Stop recording' : 'Record voice'}
            title={isRecording ? 'Stop recording' : 'Record voice'}
            className={`
              w-10 h-10 rounded-lg flex items-center justify-center transition-colors disabled:opacity-40 focus-ring
              ${isRecording
                ? 'bg-[var(--accent-red)] text-white hover:bg-red-600 shadow-md shadow-red-500/30'
                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)]'
              }
            `}
          >
            {isRecording ? <Square size={15} fill="currentColor" /> : <Mic size={18} />}
          </button>

          <div className="flex-1" />

          {/* Char count when typing */}
          {hasText && (
            <span className="text-xs text-[var(--text-tertiary)] font-mono mr-2 tabular-nums">
              {textVal.length}
            </span>
          )}

          {/* Submit */}
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!canSubmit}
            aria-label="Send report"
            title="Send report"
            className={`
              w-10 h-10 rounded-lg flex items-center justify-center transition-all focus-ring
              ${canSubmit
                ? 'bg-gradient-to-br from-[var(--accent-green)] to-[#16A34A] text-white shadow-md shadow-green-500/30 hover:shadow-lg hover:shadow-green-500/40 hover:scale-105'
                : 'bg-[var(--bg-tertiary)] text-[var(--text-tertiary)]'
              }
              disabled:cursor-not-allowed disabled:hover:scale-100
            `}
          >
            {isSubmitting ? (
              <Loader2 size={18} className="animate-spin" />
            ) : (
              <Send size={16} />
            )}
          </button>
        </div>
      </div>

      {/* Helper hint */}
      <div className="text-[11px] text-[var(--text-tertiary)] text-center mt-2 px-2">
        Press <kbd className="px-1 py-0.5 rounded bg-[var(--bg-tertiary)] border border-[var(--border-subtle)] text-[10px] font-mono">Enter</kbd> to send, <kbd className="px-1 py-0.5 rounded bg-[var(--bg-tertiary)] border border-[var(--border-subtle)] text-[10px] font-mono">Shift + Enter</kbd> for new line
      </div>
    </div>
  );
}
