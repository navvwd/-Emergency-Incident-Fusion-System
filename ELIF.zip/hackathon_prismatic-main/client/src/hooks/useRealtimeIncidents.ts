// ──────────────────────────────────────────────
// EIFS — Realtime Incidents Hook
// Prefers Supabase Realtime when configured; falls back to
// REST polling against /api/incidents when it isn't, so the
// live feed keeps working even without Supabase credentials.
// ──────────────────────────────────────────────

import { useState, useEffect, useRef } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import api from '../lib/api';
import type { Incident } from '../lib/types';

const POLL_INTERVAL_MS = 4000;

/**
 * Merge a freshly-fetched list into local state without losing ordering
 * (newest-first) or clobbering incidents the realtime channel may have
 * pushed concurrently. Uses id as the merge key.
 */
function mergeIncidents(prev: Incident[], fresh: Incident[]): Incident[] {
  if (fresh.length === 0) return prev;

  const byId = new Map<string, Incident>();
  for (const inc of fresh) byId.set(inc.id, inc);
  for (const inc of prev) {
    if (!byId.has(inc.id)) byId.set(inc.id, inc);
  }

  return Array.from(byId.values()).sort((a, b) => {
    const ta = new Date(a.updated_at || a.created_at || 0).getTime();
    const tb = new Date(b.updated_at || b.created_at || 0).getTime();
    return tb - ta;
  });
}

export function useRealtimeIncidents() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function fetchIncidents(): Promise<Incident[]> {
      try {
        const { data } = await api.get<Incident[]>('/api/incidents');
        return data || [];
      } catch (err) {
        console.error('[Realtime] Failed to fetch incidents:', err);
        return [];
      }
    }

    // ── 1. Initial fetch ─────────────────────
    fetchIncidents().then((data) => {
      if (cancelled) return;
      setIncidents(data);
      setLoading(false);
    });

    // ── 2a. Supabase Realtime (preferred) ────
    if (isSupabaseConfigured) {
      try {
        const channel = supabase
          .channel('incidents-realtime')
          .on(
            'postgres_changes',
            { event: 'INSERT', schema: 'public', table: 'incidents' },
            (payload) => {
              console.log('[Realtime] New incident:', payload.new);
              const newIncident = payload.new as Incident;
              setIncidents((prev) => mergeIncidents(prev, [newIncident]));
            }
          )
          .on(
            'postgres_changes',
            { event: 'UPDATE', schema: 'public', table: 'incidents' },
            (payload) => {
              console.log('[Realtime] Incident updated:', payload.new);
              const updated = payload.new as Incident;
              setIncidents((prev) =>
                prev.map((inc) => (inc.id === updated.id ? updated : inc))
              );
            }
          )
          .subscribe((status) => {
            console.log('[Realtime] Subscription status:', status);
          });

        channelRef.current = channel;
      } catch (err) {
        console.error('[Realtime] Failed to subscribe:', err);
      }
    } else {
      // ── 2b. Polling fallback (no Supabase) ──
      console.log(`[Realtime] Using REST polling fallback (every ${POLL_INTERVAL_MS}ms)`);
      pollRef.current = setInterval(async () => {
        const fresh = await fetchIncidents();
        if (cancelled) return;
        setIncidents((prev) => mergeIncidents(prev, fresh));
      }, POLL_INTERVAL_MS);
    }

    // ── 3. Cleanup ───────────────────────────
    return () => {
      cancelled = true;
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
      try {
        if (channelRef.current) {
          supabase.removeChannel(channelRef.current);
          channelRef.current = null;
        }
      } catch (err) {
        console.warn('[Realtime] Cleanup error:', err);
      }
    };
  }, []);

  return { incidents, loading };
}
