// ──────────────────────────────────────────────
// EIFS — Supabase Client (Frontend / Anon Key)
// ──────────────────────────────────────────────

import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

const PLACEHOLDER_URL = 'https://placeholder.supabase.co';
const PLACEHOLDER_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBsYWNlaG9sZGVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDAwMDAwMDAsImV4cCI6MjAwMDAwMDAwMH0.placeholder';

/**
 * True only when real Supabase credentials are present in env.
 * When false, callers should fall back to REST polling — the client below
 * is a harmless stub that won't crash the app.
 */
export const isSupabaseConfigured: boolean = Boolean(supabaseUrl && supabaseAnonKey);

let supabase: SupabaseClient;

try {
  if (!isSupabaseConfigured) {
    console.warn('[Supabase] Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY — realtime disabled, polling fallback will be used');
    supabase = createClient(PLACEHOLDER_URL, PLACEHOLDER_KEY);
  } else {
    supabase = createClient(supabaseUrl, supabaseAnonKey);
  }
} catch (err) {
  console.error('[Supabase] Failed to initialize client:', err);
  // Create a minimal client that won't crash the app
  supabase = createClient(PLACEHOLDER_URL, PLACEHOLDER_KEY);
}

export { supabase };
