// ──────────────────────────────────────────────
// EIFS — Vision Service (PRIMARY)
//
// Single-call image understanding via OpenAI gpt-4o-mini vision.
// Returns BOTH OCR text and a factual scene description so the entity
// extraction stage gets fully labelled context.
//
// Why OpenAI here:
// - Sarvam's chat-completions endpoint is text-only (verified against
//   the official OpenAPI spec); its only vision option is the async
//   /doc-digitization job pipeline which is too slow for the realtime
//   ingest pipeline.
// - OpenAI gpt-4o-mini is synchronous, ~1-3s, and very cheap.
// - Moonshot is kept as a secondary fallback (see services/moonshot.ts)
//   so its surface area in the pipeline stays minimal.
// ──────────────────────────────────────────────

import axios from 'axios';

const OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions';
const VISION_MODEL = 'gpt-4o-mini';

const SYSTEM_PROMPT =
  'You are an emergency-scene analyst for India. Given a photograph from a citizen report, you produce TWO labelled sections so a downstream parser can read them.';

const USER_PROMPT = [
  'Analyse this emergency image and respond in EXACTLY this format (no markdown, no extra prose):',
  '',
  'OCR: <every piece of visible text — street signs, shop names, building names, hospital/school names, banners, hoardings, vehicle number plates, landmarks. Translate any Indian-language text to English in parentheses. If there is no readable text, write "none".>',
  'SCENE: <2-3 factual sentences describing the incident type (accident/fire/flood/collapse/medical/etc), visible damage or danger, number of people likely affected, vehicles or infrastructure involved, terrain (urban/rural/coastal/hilly). Mention every location clue you can read.>',
  '',
  'Be concise. No bullet points, no extra headers besides "OCR:" and "SCENE:".',
].join('\n');

export interface ImageDescription {
  ocr: string;
  scene: string;
}

/**
 * Describe an image in a single call. Returns labelled OCR + scene text.
 *
 * Throws on transport / auth / API failure so the caller can fall back
 * to the Moonshot path or surface a 422 to the client.
 */
export async function describeImage(
  imageBuffer: Buffer,
  fileName: string,
): Promise<ImageDescription> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error('[Vision] OPENAI_API_KEY is not set in environment variables');
  }

  const start = Date.now();
  const mimeType = fileName.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
  const dataUrl = `data:${mimeType};base64,${imageBuffer.toString('base64')}`;

  try {
    const response = await axios.post(
      OPENAI_API_URL,
      {
        model: VISION_MODEL,
        max_tokens: 600,
        temperature: 0.1,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          {
            role: 'user',
            content: [
              { type: 'text', text: USER_PROMPT },
              { type: 'image_url', image_url: { url: dataUrl, detail: 'low' } },
            ],
          },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        // OpenAI vision can take 8-12s for the first call; allow headroom
        // so the resilience layer doesn't trigger an expensive retry.
        timeout: 25000,
      },
    );

    const raw = (response.data?.choices?.[0]?.message?.content || '').trim();

    // Parse the strict OCR: / SCENE: format
    const ocrMatch = raw.match(/OCR:\s*([\s\S]*?)(?:\n\s*SCENE:|$)/i);
    const sceneMatch = raw.match(/SCENE:\s*([\s\S]*?)$/i);

    let ocr = (ocrMatch?.[1] || '').trim();
    let scene = (sceneMatch?.[1] || '').trim();

    // Graceful degradation: if the model ignored the format, treat the
    // entire reply as scene text and leave OCR empty.
    if (!ocr && !scene) {
      scene = raw;
    }

    // Normalise sentinel "none" to empty string
    if (/^none\.?$/i.test(ocr)) ocr = '';

    const elapsed = Date.now() - start;
    console.log(`[Vision] describeImage in ${elapsed}ms | ocr=${ocr.length}c scene=${scene.length}c`);

    return { ocr, scene };
  } catch (error: any) {
    const elapsed = Date.now() - start;
    const msg = error.response?.data?.error?.message || error.message;
    console.error(`[Vision] describeImage failed after ${elapsed}ms: ${msg}`);
    throw new Error(`[Vision] describeImage failed: ${msg}`);
  }
}
