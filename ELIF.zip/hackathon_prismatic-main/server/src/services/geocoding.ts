// ──────────────────────────────────────────────
// EIFS — Reverse Geocoding (OpenStreetMap Nominatim)
// Converts a lat/lng pair into a short human-readable
// "Area, City, State" string for incident display.
//
// Nominatim usage policy: max 1 req/s, real User-Agent required.
// https://operations.osmfoundation.org/policies/nominatim/
// ──────────────────────────────────────────────

import axios from 'axios';

const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/reverse';
const REQUEST_TIMEOUT_MS = 3500;
const USER_AGENT = 'EIFS-Emergency-Intelligence-Fusion/1.0 (hackathon-prismatic)';

interface NominatimAddress {
  road?: string;
  suburb?: string;
  neighbourhood?: string;
  village?: string;
  town?: string;
  city?: string;
  city_district?: string;
  county?: string;
  state_district?: string;
  state?: string;
  country?: string;
  postcode?: string;
}

interface NominatimResponse {
  display_name?: string;
  address?: NominatimAddress;
  error?: string;
}

/**
 * Reverse-geocode a lat/lng into a short display string like
 *   "Koramangala, Bengaluru, Karnataka"
 *
 * Returns null on any failure — caller should fall back gracefully.
 */
export async function reverseGeocode(
  latitude: number,
  longitude: number,
): Promise<string | null> {
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    return null;
  }

  const start = Date.now();

  try {
    const response = await axios.get<NominatimResponse>(NOMINATIM_URL, {
      params: {
        lat: latitude,
        lon: longitude,
        format: 'jsonv2',
        zoom: 16, // neighbourhood-level detail
        addressdetails: 1,
      },
      headers: {
        'User-Agent': USER_AGENT,
        'Accept-Language': 'en',
      },
      timeout: REQUEST_TIMEOUT_MS,
    });

    const elapsed = Date.now() - start;

    if (response.data.error || !response.data.address) {
      console.warn(`[Geocode] No address for ${latitude},${longitude} in ${elapsed}ms`);
      return null;
    }

    const formatted = formatAddress(response.data.address);
    console.log(`[Geocode] ${latitude.toFixed(4)},${longitude.toFixed(4)} → "${formatted}" in ${elapsed}ms`);
    return formatted;
  } catch (error: any) {
    const elapsed = Date.now() - start;
    const msg = error.response?.data?.error || error.message;
    console.warn(`[Geocode] Failed after ${elapsed}ms: ${msg}`);
    return null;
  }
}

/**
 * Build a compact display string from Nominatim's address parts.
 * Prefers area → city → state, deduplicating when parts overlap
 * (e.g. in small towns where city and county match).
 */
function formatAddress(addr: NominatimAddress): string {
  const area =
    addr.suburb ||
    addr.neighbourhood ||
    addr.city_district ||
    addr.village ||
    addr.road;
  const city = addr.city || addr.town || addr.county;
  const state = addr.state;

  const seen = new Set<string>();
  const unique: string[] = [];
  for (const part of [area, city, state]) {
    if (part && !seen.has(part)) {
      seen.add(part);
      unique.push(part);
    }
  }

  if (unique.length === 0) {
    return addr.country || 'Unknown location';
  }

  return unique.join(', ');
}

/**
 * Phrases that indicate a location string carries no useful geo-information
 * and should be overwritten via reverse-geocoding when GPS is available.
 *
 * Matched as substrings on the lowercased, punctuation-stripped string so we
 * catch variations like:
 *   "Location not specified"
 *   "Not specified, India"
 *   "Unknown location"
 *   "Unspecified location, India"
 *   "N/A"
 */
const VAGUE_PHRASES = [
  'not specified',
  'unspecified',
  'unknown',
  'not provided',
  'not mentioned',
  'not available',
  'no location',
  'location missing',
  'n/a',
];

/**
 * Countries/regions that are too broad to be useful on their own.
 * Only flagged when they're the ENTIRE location string (not a substring),
 * so "Chennai, Tamil Nadu, India" still passes.
 */
const VAGUE_STANDALONE = new Set([
  'india',
  'unknown',
  'n/a',
  'na',
  '-',
  '—',
]);

/**
 * Returns true when a location string is too generic to be useful
 * and should be overwritten by reverse-geocoding.
 */
export function isVagueLocation(location: string | undefined | null): boolean {
  if (!location) return true;

  const normalized = location.trim().toLowerCase();
  if (normalized.length === 0) return true;

  // Whole-string matches against known bare placeholders
  if (VAGUE_STANDALONE.has(normalized)) return true;

  // Substring match — catches "Location not specified",
  // "Not specified, India", "Unknown location", etc.
  for (const phrase of VAGUE_PHRASES) {
    if (normalized.includes(phrase)) return true;
  }

  return false;
}
