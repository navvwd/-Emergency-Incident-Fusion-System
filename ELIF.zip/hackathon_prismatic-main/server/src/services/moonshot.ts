// ──────────────────────────────────────────────
// EIFS — Moonshot Kimi Vision Service (FALLBACK ONLY)
//
// OpenAI gpt-4o-mini is the primary vision provider — see
// `services/vision.ts`. Moonshot is invoked only when the primary
// returns no usable output AND its circuit breaker is closed. Keep
// this file minimal so the secondary surface area stays small.
//
// Sarvam is intentionally NOT in the vision path: its chat-completions
// endpoint is text-only and its only image API is the async
// /doc-digitization job pipeline, which is too slow for realtime ingest.
// ──────────────────────────────────────────────

import axios from 'axios';

const MOONSHOT_API_URL = 'https://api.moonshot.cn/v1/chat/completions';
const MOONSHOT_VISION_MODEL = 'moonshot-v1-8k-vision-preview';

// Vision prompt — optimized for emergency scene + location extraction
const VISION_PROMPT = `Analyze this emergency image. Focus on:

1. Incident type (accident, fire, flood, collapse, medical, etc.)
2. Visible damage, injuries, or danger
3. LOCATION — this is critical. Look carefully for:
   - Street signs, road names, highway markers, mile markers
   - Building names, shop signs, hospital names, school names
   - Landmarks (temples, bridges, flyovers, railway crossings, bus stops)
   - Vehicle number plates (Indian plates indicate state/city)
   - Any text on banners, hoardings, or walls that hints at area/city
   - Terrain and surroundings (urban/rural, coastal, hilly, etc.)
4. Number of people visible or likely affected
5. Vehicles, equipment, or infrastructure involved

Be factual and concise. 2-3 sentences. Prioritize location clues — mention every sign, name, or landmark you can read.`;

/**
 * Fallback scene description. Only invoked from the report pipeline when
 * Sarvam vision returns empty output AND the moonshot circuit is closed.
 */
export async function describeScene(imageBuffer: Buffer): Promise<string> {
  const apiKey = process.env.MOONSHOT_API_KEY;
  if (!apiKey) {
    throw new Error('[Moonshot] MOONSHOT_API_KEY is not set in environment variables');
  }

  const start = Date.now();

  try {
    const base64Image = imageBuffer.toString('base64');
    const dataUrl = `data:image/jpeg;base64,${base64Image}`;

    const response = await axios.post(
      MOONSHOT_API_URL,
      {
        model: MOONSHOT_VISION_MODEL,
        max_tokens: 300,
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: VISION_PROMPT },
              { type: 'image_url', image_url: { url: dataUrl } },
            ],
          },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
      },
    );

    const description = response.data?.choices?.[0]?.message?.content || '';

    const elapsed = Date.now() - start;
    console.log(`[Moonshot Vision] (fallback) Scene described in ${elapsed}ms (${description.length} chars)`);

    return description;
  } catch (error: any) {
    const elapsed = Date.now() - start;
    const msg = error.response?.data?.error?.message || error.message;
    console.error(`[Moonshot Vision] (fallback) Failed after ${elapsed}ms: ${msg}`);
    throw new Error(`[Moonshot Vision] Scene description failed: ${msg}`);
  }
}
